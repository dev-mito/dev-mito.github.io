@echo off

docker compose up -d
docker logs -f papermc_server

pause