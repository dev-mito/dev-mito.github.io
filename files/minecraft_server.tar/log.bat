@echo off

docker logs -f papermc_server

pause